// import React from 'react'
// import FreeCardContainer from './FreeCardContainer';
// import Group from './Group';
// import SectionCombined from './SectionCombined';

// function Home() {
//   return (
//       <div>
//     {/* <FreeCardContainer /> */}
  
//     <SectionCombined />
    
//     <Group />
//     </div>
//   )
// }

// export default Home